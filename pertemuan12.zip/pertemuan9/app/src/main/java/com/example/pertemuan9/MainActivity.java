package com.example.pertemuan9;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    String[] namaOrang = {"Andi", "Budi", "Citra", "Dewi"};
    String[] umurOrang = {"21 tahun", "25 tahun", "19 tahun", "23 tahun"};
    int[] gambarOrang = {
            R.drawable.andi,
            R.drawable.budi,
            R.drawable.citra,
            R.drawable.dewi
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listNama);
        CustomAdapter2 adapter = new CustomAdapter2();
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String nama = namaOrang[position];
            String umur = umurOrang[position];

            Intent intent = new Intent(MainActivity.this, profileActivity.class);
            startActivity(intent);
            intent.putExtra("Nama",nama);
            intent.putExtra("Umur",umur);

            startActivity(intent);


            Toast.makeText(MainActivity.this, nama + ", " + umur, Toast.LENGTH_SHORT).show();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top+50, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    class CustomAdapter2 extends BaseAdapter {
        @Override
        public int getCount() {
            return namaOrang.length;
        }

        @Override
        public Object getItem(int position) {
            return namaOrang[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(MainActivity.this)
                        .inflate(R.layout.list_item, parent, false);
            }

            TextView textNama = convertView.findViewById(R.id.textNama);
            TextView textUmur = convertView.findViewById(R.id.textUmur);
            ImageView imageView = convertView.findViewById(R.id.imageView);

            textNama.setText(namaOrang[position]);
            textUmur.setText(umurOrang[position]);
            imageView.setImageResource(gambarOrang[position]);

            return convertView;
        }
    }
}