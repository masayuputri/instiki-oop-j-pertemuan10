package com.example.pertemuan9;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class profileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);

        String namaTerima = getIntent().getStringExtra("Nama");
        String umurTerima = getIntent().getStringExtra("Umur");

        TextView textNama = findViewById(R.id.textNama);
        TextView textUmur = findViewById(R.id.textUmur);

        textNama.setText(namaTerima);
        textUmur.setText(umurTerima);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top+50, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}